# SmartPay Phones Uganda — cPanel PHP Deployment

This package is designed for standard cPanel hosting with **PHP 7.4 or newer**, MySQL/MariaDB, HTTPS, PDO MySQL, and PHP sessions.

## Installation

1. Create a MySQL database and database user in cPanel. Grant the user all privileges on that database.
2. Open phpMyAdmin and import `docs/database-setup.sql`. If the host does not allow `CREATE DATABASE`, select the created database first and remove the first two SQL lines.
3. Edit `api/config.php` and replace `DB_NAME`, `DB_USER`, and `DB_PASS`. Keep `DB_HOST` as `localhost` unless your host gives a different value.
4. Upload the package contents so `index.html`, `admin.html`, `api/`, `css/`, `js/`, `assets/`, `docs/`, and `private-tickets/` are directly inside `public_html`.
5. Enable an SSL certificate and force HTTPS. Secure session cookies should never be used over plain HTTP.
6. Open `index.html` and test catalogue loading, account registration, login, order creation, MTN-reference submission, and the copy-number button.
7. To create the first administrator, register a normal account, then run `UPDATE users SET role='admin' WHERE email='your-real-admin-email@example.com';` in phpMyAdmin. Sign out and back in before opening `admin.html`.
8. Change the payment/contact settings from `admin.html` or run `docs/manual-payment-migration.sql` after selecting the correct database.

## File placement

The PHP files remain inside `api/`; they are called by JavaScript using relative URLs. Do not move them into a different directory unless you also update `js/main.js` and `js/admin.js`.

## Security checklist

Keep `api/config.php` readable only by the cPanel account and never commit real credentials into a public repository. Keep HTTPS enabled, use a strong database password, remove phpMyAdmin access when not needed, and back up the database before migrations. The provided `private-tickets/.htaccess` blocks common sensitive file types in that directory. If your host supports it, also disable directory listing and protect database backups outside `public_html`.

## What works in this package

The package includes a PHP/MySQL public catalogue, customer registration/login, session-protected customer orders and payment-reference submission, role-protected admin login, product/stock management, order status management, payment verification endpoint, editable business/payment settings, and review management restricted to completed orders.

This is a new standalone PHP implementation. It does not use Node.js, React, tRPC, Manus OAuth, or a build step. It uses the browser’s standard Fetch API and PHP’s PDO/session features.

## Current application behavior

The public application uses a guided four-step interface. A customer must register or sign in, choose a product and plan, enter personal and delivery details, review the MTN deposit instructions, and submit the order. The order is saved by `api/marketplace.php` and appears in `dashboard.html`; it is not submitted to WhatsApp. Payment references are submitted from the dashboard for administrator verification.

The package includes `dashboard.html` and `js/dashboard.js` so the customer account is available as a dedicated cPanel page, in addition to the account modal on `index.html`.
