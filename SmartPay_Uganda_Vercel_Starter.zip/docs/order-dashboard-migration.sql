-- Run once on an existing SmartPay database before deploying this update.
ALTER TABLE orders
  ADD COLUMN preferred_colour VARCHAR(50) NULL AFTER deposit_amount,
  ADD COLUMN payment_frequency ENUM('daily','weekly','monthly') NOT NULL DEFAULT 'daily' AFTER preferred_colour,
  ADD COLUMN delivery_method ENUM('home_delivery','office_collection') NOT NULL DEFAULT 'home_delivery' AFTER payment_frequency,
  ADD COLUMN delivery_notes TEXT NULL AFTER delivery_method;
