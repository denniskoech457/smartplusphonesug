# SmartPay Phones Uganda PHP API

All endpoints are relative to `api/` and return JSON. POST requests use JSON bodies and the session cookie. Successful authentication returns a CSRF token; send it as `X-CSRF-Token` and as `csrf` in POST bodies.

| Endpoint | Action | Access | Purpose |
|---|---|---|---|
| `auth.php?action=me` | GET | Public | Return the current session and CSRF token |
| `auth.php?action=register` | POST | Public | Create a customer account |
| `auth.php?action=login` | POST | Public | Start a customer or administrator session |
| `auth.php?action=logout` | POST | Signed in | Destroy the current session |
| `marketplace.php?action=products` | GET | Public | List active in-stock products |
| `marketplace.php?action=settings` | GET | Public | Read public contact/payment settings |
| `marketplace.php?action=reviews` | GET | Public | List published reviews linked to completed orders |
| `marketplace.php?action=order` | POST | Customer | Create an order for an in-stock product |
| `marketplace.php?action=my_orders` | GET | Customer | List the signed-in customer’s orders |
| `marketplace.php?action=payment` | POST | Customer | Submit an MTN reference and optional message |
| `admin.php?action=overview` | GET | Admin | Load orders, products, reviews, and settings |
| `admin.php?action=product_save` | POST | Admin | Add or edit an inventory item |
| `admin.php?action=product_delete` | POST | Admin | Remove an inventory item |
| `admin.php?action=settings_save` | POST | Admin | Update MTN/contact settings |
| `admin.php?action=order_status` | POST | Admin | Update an order workflow status |
| `admin.php?action=payment_verify` | POST | Admin | Verify or reject a submitted payment |
| `admin.php?action=review_save` | POST | Admin | Add or edit genuine feedback linked to a completed order |
| `admin.php?action=review_delete` | POST | Admin | Remove a review |

The backend uses PDO prepared statements, password hashing, session regeneration on login, CSRF protection for state-changing requests, role checks for administrator actions, and server-side stock/order ownership checks. Do not expose `api/config.php` or database credentials publicly. Change the placeholder database constants before installation.
