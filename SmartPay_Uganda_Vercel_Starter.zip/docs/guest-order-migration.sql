-- Enable guest checkout.
-- orders.user_id must be nullable because a guest does not have a users row.
ALTER TABLE orders MODIFY user_id INT UNSIGNED NULL;

-- If your existing foreign key uses ON DELETE CASCADE, it may remain in place;
-- NULL guest user_id values are valid and do not require a users record.
