USE easypay_phones;
INSERT INTO business_settings(setting_key,setting_value) VALUES
('mtn_number','0794421398'),('mtn_name','Amina'),('support_phone','0794421398'),('support_email','Info@easypayphonesuganda.site'),('location','Acacia Mall, Kampala, Uganda')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);
