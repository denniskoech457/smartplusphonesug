
CREATE TABLE leadership_members (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(160) NOT NULL,
  role VARCHAR(160) NOT NULL,
  bio TEXT NOT NULL,
  image_url VARCHAR(500) NOT NULL DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO leadership_members(full_name,role,bio,image_url,sort_order,is_active) VALUES
('Jackson Wogongoba','CEO','Founder and CEO with 15+ years in telecommunications and retail. Visionary leader committed to making smartphones accessible to every Ugandan.','',1,1),
('Amina Nakato','Sales Manager','Drives customer acquisition and manages our sales team. Passionate about customer satisfaction and building lasting relationships.','',2,1),
('David Okello','Operations Director','Oversees logistics, inventory, and delivery operations. Ensures every customer receives their phone on time and in perfect condition.','',3,1);
