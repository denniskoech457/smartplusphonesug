-- Run this only if your existing orders table does not already have alternative_number.
ALTER TABLE orders ADD COLUMN alternative_number VARCHAR(40) NULL AFTER phone_number;
