-- Run this on an existing SmartPay database if users.whatsapp_number does not exist.
ALTER TABLE users ADD COLUMN whatsapp_number VARCHAR(40) NULL AFTER email;
