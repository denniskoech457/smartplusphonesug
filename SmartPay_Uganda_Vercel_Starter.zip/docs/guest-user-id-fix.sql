-- Guest order compatibility fix.
-- Run this ONLY if your existing orders table has a user_id column that is NOT NULL.
-- If your orders table does not have user_id at all, no database change is required.

ALTER TABLE orders MODIFY user_id INT UNSIGNED NULL;
