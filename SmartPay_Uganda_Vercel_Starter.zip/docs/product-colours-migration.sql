-- Run this once on an existing SmartPay database before using the updated admin product colour field.
ALTER TABLE products ADD COLUMN available_colours VARCHAR(500) NOT NULL DEFAULT '' AFTER daily_rate;

UPDATE products SET available_colours = CASE
  WHEN LOWER(brand) = 'apple' THEN 'Midnight, Starlight, Blue, Pink, Green, Red'
  WHEN LOWER(brand) = 'samsung' THEN 'Black, Light Green, Gold, White'
  WHEN LOWER(brand) = 'tecno' THEN 'Black, White, Blue, Green'
  WHEN LOWER(brand) = 'infinix' THEN 'Black, Titanium, Green, Purple'
  WHEN LOWER(brand) = 'redmi' THEN 'Midnight Black, Starry Blue, Sage Green, Purple'
  WHEN LOWER(brand) = 'itel' THEN 'Black, Blue, Green, Gold'
  ELSE 'Black, White, Blue, Green'
END
WHERE available_colours = '';
