-- Run this once on an existing SmartPay database before uploading the updated marketplace.php.
ALTER TABLE orders
  ADD COLUMN national_id VARCHAR(40) NULL AFTER full_name,
  ADD COLUMN alternative_number VARCHAR(40) NULL AFTER phone_number,
  ADD COLUMN contact_email VARCHAR(190) NULL AFTER alternative_number;
