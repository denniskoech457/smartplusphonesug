-- Allow admin-created standalone testimonials and customer photos
ALTER TABLE customer_reviews MODIFY order_id INT UNSIGNED NULL;
ALTER TABLE customer_reviews ADD COLUMN customer_photo VARCHAR(500) NOT NULL DEFAULT '' AFTER customer_name;
